package com.assignment.friendmanagement.model.response;

/**
 * Created by Shahul Hameed on 21/08/2018
 */

public class EmailResponse {

    private String email;

    public EmailResponse() {
    }

    public EmailResponse(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        EmailResponse that = (EmailResponse) o;

        return email != null ? email.equals(that.email) : that.email == null;
    }

    @Override
    public int hashCode() {
        return email != null ? email.hashCode() : 0;
    }
}
