package com.assignment.friendmanagement.service;

/**
 * Created by Shahul Hameed on 21/08/2018
 */

import com.assignment.friendmanagement.model.response.MessageRecipientsResponse;

public interface MessagingService {

    MessageRecipientsResponse sendMessage(String sender, String text);
}
