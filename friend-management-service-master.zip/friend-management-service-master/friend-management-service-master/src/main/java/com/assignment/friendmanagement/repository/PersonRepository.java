package com.assignment.friendmanagement.repository;

/**
 * Created by Shahul Hameed on 21/08/2018
 */


import com.assignment.friendmanagement.model.Person;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PersonRepository extends CrudRepository<Person, Long> {
    Person findByEmail(String email);
}
