package com.assignment.friendmanagement.utils;

import org.junit.Assert;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by Shahul Hameed on 21/08/2018
 */

public class EmailUtilsTest {

    private EmailUtils emailUtils = new EmailUtils();

    @Test
    public void texWithMultipleEmails() {
        String text = "This  di Kiya kotha gey email saya test.crb@outlook.com tks...\n" +
                "Apna Ampa Ki kumba keke sap.sulaiman@gmail.com. \n" +
                "hey.woo@yahoo.com. b@b b@b.c b.@b a..@a .\n" +
                "kemtheke@yahoo.co.id Senior Quantity Surveyor\n" +
                "shahulhameed@hotmail.com, remba Nantry JayaKumar\n" +
                "test.mail@gmail.com kiya ko kaya Guindy\n" +
                "kukumkotha@gmail.com \n" +
                "Hi Nancy ...pls share the Salary guide to kun_tri_windy@yahoo.co.id thank a ka@tc.co ";
        List<String> strings = emailUtils.retrieveEmailIdsFromText(text);
        Assert.assertEquals(strings.size(), 10);
    }

    @Test
    public void textWithNoEmails() {
        String text = "random test @ I don't have email";
        List<String> strings = emailUtils.retrieveEmailIdsFromText(text);
        Assert.assertEquals(strings.size(), 0);

    }

    @Test
    public void textInvalidEmails() {
        String text = "random test x...@ I am invalid email";
        List<String> strings = emailUtils.retrieveEmailIdsFromText(text);
        Assert.assertEquals(strings.size(), 0);
    }

}